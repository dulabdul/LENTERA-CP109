# 01 — Product Requirements Document (PRD)

## 1. Latar Belakang & Masalah
Kebakaran Hutan dan Lahan (Karhutla) serta bencana kabut asap lintas batas (*transboundary haze*) merupakan ancaman tahunan di Indonesia, khususnya di wilayah rentan gambut seperti Riau, Jambi, Sumatera Selatan, serta Kalimantan Barat, Tengah, dan Selatan. 

Seringkali data mengenai titik api (*hotspot*) dan kualitas udara (PM2.5) tersebar di berbagai portal yang terpisah, sulit diakses oleh masyarakat umum di ponsel cerdas, atau dibatasi oleh antarmuka yang lambat dan kaku.

**Lentera Karhutla** hadir sebagai observatorium independen, terbuka, dan cepat yang menggabungkan dua fenomena kunci ke dalam satu layar:
1. **Di mana api membara?** (Titik panas termal satelit NASA).
2. **Ke mana asap tertiup dan seberapa bahaya udaranya?** (Konsentrasi partikulat PM2.5 & arah angin 10m).

---

## 2. Ruang Lingkup Produk (*Product Scope*)

Proyek ini dibatasi secara ketat pada **tiga pilar fitur** utama agar tetap ramping, cepat di-deploy, dan tanpa biaya operasional server (*zero-dollar maintenance*):

```
┌────────────────────────────────────────────────────────────────────────┐
│                        LENTERA KARHUTLA PILARS                         │
└────────────────────────────────────────────────────────────────────────┘
          │                                 │                    │
          ▼                                 ▼                    ▼
   [ 1. HERO SECTION ]            [ 2. MAP DASHBOARD ]    [ 3. DATA SOURCES ]
   • Narasi editorial urgensi     • Titik panas NASA      • Atribusi NASA FIRMS
   • Metrik telemetry aktif       • Lapisan PM2.5 & angin • Atribusi Open-Meteo
   • Quick action CTA             • Filter waktu (24h/7d) • Metodologi & batas
```

### A. Fitur 1: Halaman Utama / Hero Section
* **Editorial Headline:** Judul dan sub-judul berkarakter jurnalisme investigatif yang memaparkan situasi kebakaran hutan Indonesia secara objektif (*evidence over accusation*).
* **Live Telemetry Banner:** Menampilkan 3 metrik cepat yang di-fetch secara instan:
  * Jumlah titik panas (*hotspots*) aktif terdeteksi di Indonesia dalam 24 jam terakhir.
  * Wilayah / provinsi dengan konsentrasi titik api tertinggi (misal: Riau, Kalteng).
  * Indeks kualitas udara terburuk yang terdeteksi saat ini.
* **Call-to-Action (CTA):** Tombol terintegrasi *"Buka Peta Interaktif"* yang memindahkan pengguna ke dashboard peta dengan transisi halus.

### B. Fitur 2: Dashboard Peta Interaktif (Karhutla & PM2.5)
* **Visualisasi Titik Panas (NASA FIRMS Hotspots):**
  * Menampilkan titik api dari satelit VIIRS (resolusi 375m) dan MODIS (1km) dalam bentuk titik berpendar (*pulsing glowing dots*) atau klaster (*cluster*) pada zoom jauh.
  * Informasi detail saat titik diklik: koordinat (Lat/Lng), tingkat keyakinan (*confidence level* / nominal/high), waktu deteksi UTC/WIB, dan satelit pendeteksi.
* **Visualisasi Kualitas Udara & Partikel Angin:**
  * Lapisan gradasi warna PM2.5 (Hijau = Baik, Kuning = Sedang, Oranye = Tidak Sehat bagi Sensitif, Merah = Berbahaya).
  * Lapisan partikel angin yang bergerak di atas canvas 2D untuk memvisualisasikan ke arah mana asap tertiup.
* **Timeline Scrubber (Slider Waktu):**
  * Opsi rentang waktu: **24 Jam Terakhir**, **48 Jam Terakhir**, dan **7 Hari Terakhir**.
* **Kontrol Peta Interaktif:**
  * Tombol zoom, reset pandangan ke batas kepulauan Indonesia (*fit bounds* Sabang–Merauke), dan saklar pemilih basemap (Mode Gelap Arang / Mode Terang Kontras).

### C. Fitur 3: Halaman Sumber Data & Transparansi Ilmiah
* **Katalog Sumber Data Terbuka:**
  * **NASA FIRMS (LANCE):** Penjelasan instrumen Suomi-NPP, NOAA-20/21, dan Aqua/Terra.
  * **Open-Meteo & Copernicus Atmosphere Monitoring Service (CAMS):** Penjelasan data model atmosfer PM2.5 dan vektor angin.
  * **CARTO & OpenStreetMap:** Atribusi lisensi peta vektor.
* **Metodologi & Batasan Satelit:**
  * Klarifikasi bahwa deteksi satelit adalah anomali termal inframerah, yang bisa terhalang awan tebal dan memerlukan verifikasi lapangan oleh Manggala Agni / BPBD.
* **Pemberitahuan Lisensi Proyek:** Lisensi terbuka buatan sendiri (MIT/Apache 2.0).

---

## 3. Matriks Fitur (In-Scope vs Out-of-Scope)

| Fitur | Status | Rationale |
| :--- | :---: | :--- |
| **Peta Titik Api NASA FIRMS** | ✅ **In-Scope** | Komponen vital pemantau karhutla. |
| **Simulasi Partikel Angin & PM2.5** | ✅ **In-Scope** | Esensial untuk memahami arah sebaran kabut asap. |
| **Timeline Waktu (24h/48h/7d)** | ✅ **In-Scope** | Memantau perkembangan harian titik api. |
| **Hero Section & Data Sources** | ✅ **In-Scope** | Konteks narasi dan edukasi publik. |
| **Data Satwa Terancam Punah** | ❌ **Out-of-Scope** | Fitur khusus Mandum Rimba, tidak relevan untuk fokus karhutla murni. |
| **Pembuat KTP Satwa (KTP Tool)** | ❌ **Out-of-Scope** | Bersifat gamifikasi, ditiadakan agar aplikasi tetap profesional dan fokus. |
| **Batas Konsesi Sawit/Tambang** | ❌ **Out-of-Scope** | Membutuhkan file PMTiles multi-gigabyte dan pemeliharaan data spasial berat. |
| **Database PostgreSQL / Redis** | ❌ **Out-of-Scope** | Dihilangkan total; arsitektur dibuat *stateless serverless* langsung ke API publik. |

---

## 4. Non-Functional Requirements (NFR)

1. **Performa Rendering:** 
   * Peta dan partikel angin harus berjalan mulus pada **60 FPS** di browser desktop dan minimal **45 FPS** di perangkat mobile Android/iOS menengah.
   * Total ukuran initial bundle JavaScript di bawah **250 KB (gzipped)** di luar library MapLibre GL.
2. **Latensi Data:** Data titik api NASA diambil secara *on-demand* dengan caching edge (Vercel Edge Cache) selama 30–60 menit untuk mencegah *rate-limit* NASA.
3. **Privasi Pengguna:** **Zero Tracking, Zero Cookies.** Tidak ada pelacakan GPS otomatis; pencarian kota bersifat manual dan tidak menyimpan riwayat pengguna.
4. **Biaya Infrastruktur:** **Rp 0 / Bulan.** Didesain untuk dapat di-host secara gratis di Vercel Hobby Tier atau Cloudflare Pages.
