# 03 — UI/UX Design System & Anti-Slop Guidelines

## 1. Filosofi Desain: *The Anti-Slop Direction*

Sesuai panduan dari **Taste-Skill (`Leonxlnx/taste-skill`)**, antarmuka AI generik sering kali jatuh ke dalam perangkap yang sama: *headline di tengah dengan 3 baris, badge kecil di atasnya, 3 kartu fitur melayang dengan bayangan ungu, gradien lembut murahan, dan tipografi browser biasa*.

**Lentera Karhutla menolak template AI generik tersebut.** Desainnya diarahkan sebagai **Observatorium Investigatif Forensik Lingkungan**:
* **Mood:** Forensik, serius, berbasis bukti (*evidence-based*), bernuansa observatorium sains malam hari.
* **Karakter:** Layout asimetris yang berani, kontras tinggi, angka telemetri yang presisi, dan visualisasi data yang berbicara sendiri tanpa dekorasi hampa (*no meaningless ornaments*).

---

## 2. Token Desain & Palet Warna

### A. Palet Warna (Dark-Mode First)

```
[ Obsidian Core ]      [ Ash Border ]       [ Pure Ember ]       [ Toxic Haze ]
   #090D12               #212833               #FF3E24              #9A59B5
  (Latar Belakang)       (Batas & Garis)       (Titik Api Utama)    (PM2.5 Berbahaya)
```

| Nama Token | Hex Code | Peran / Penggunaan |
| :--- | :---: | :--- |
| `bg-obsidian` | `#090D12` | Latar belakang kanvas utama (menonjolkan warna api). |
| `bg-surface` | `#111720` | Kartu telemetri, panel samping, dan drawer kontrol. |
| `border-subtle` | `#212833` | Garis pemisah tegas dan rapi (1px crisp border). |
| `text-primary` | `#F2F5F8` | Teks utama, judul, dan angka telemetri kontras tinggi. |
| `text-muted` | `#7D8B9B` | Label unit, keterangan tanggal, koordinat GPS. |
| `fire-high` | `#FF3E24` | Titik api dengan *high confidence* (pendar oranye-merah). |
| `fire-nominal` | `#FF9E1B` | Titik api dengan *nominal confidence* (amber hangat). |
| `pm25-good` | `#10B981` | Udara bersih / PM2.5 sehat (Emerald). |
| `pm25-moderate` | `#F59E0B` | Udara sedang / PM2.5 sedang (Amber). |
| `pm25-danger` | `#8B5CF6` | Udara berbahaya / PM2.5 tinggi (Ungu tua pekat). |

### B. Tipografi Berkarakter

1. **Headline & Judul Editorial:** **`Fraunces`** atau **`Instrument Serif`** (Google Fonts).
   * Memberikan bobot jurnalisme investigatif dan wibawa observatorium independen, bukan sekadar SaaS startup biasa.
2. **Body & Antarmuka UI:** **`Plus Jakarta Sans`** atau **`Inter`**.
   * Sangat mudah dibaca pada ukuran kecil (12–14px) untuk label layer dan navigasi.
3. **Telemetri, Tanggal, & Koordinat:** **`JetBrains Mono`** atau **`Geist Mono`**.
   * Menampilkan angka dengan spasi tabular (`tabular-nums`) agar data titik api, koordinat lat/lng, dan angka µg/m³ tidak bergeser saat data ter-refresh.

---

## 3. Cetak Biru Tampilan (*Screen Blueprints*)

### A. Cetak Biru Halaman Utama (Hero Section)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [🔥 LENTERA KARHUTLA]                 [Peta Interaktif] [Sumber Data]   │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  INDONESIA TERBAKAR DARI LANGIT.                                       │
│                                                                        │
│  Observatorium independen yang memetakan anomali termal satelit        │
│  NASA dan pergerakan partikel asap PM2.5 di atas tanah air secara      │
│  real-time.                                                            │
│                                                                        │
│  [ 🔴 Buka Peta Sekarang ]   [ Pelajari Metodologi ↗ ]                 │
│                                                                        │
├────────────────────────────────────────────────────────────────────────┤
│ TELEMETRY TICKER (Live Sensor Stream)                                  │
│ ┌──────────────────────┐ ┌──────────────────────┐ ┌──────────────────┐ │
│ │ 342 TITIK PANAS AKTIF│ │ KONSENTRASI TERTINGGI│ │ STATUS UDARA     │ │
│ │ 24 Jam Terakhir (IDN)│ │ Riau & Kalteng       │ │ 184 µg/m³ (Buruk)│ │
│ └──────────────────────┘ └──────────────────────┘ └──────────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

### B. Cetak Biru Dashboard Peta (Karhutla & PM2.5)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [← Kembali]   🔴 LIVE MONITOR: 19 OKT 2026   [Layer ☰]   [Sabang-Merauke ⛶]│
├─────────────────────────────────────────────┬──────────────────────────┤
│                                             │ TELEMETRI TERPILIH       │
│               PETA MAPLIBRE GL              │ ───────────────────────  │
│                                             │ Titik: Hotspot VIIRS-NRT │
│     🔥 (Hotspot Pendar Merah)               │ Koordinat: 0.538N, 101.4E│
│           ~ ~ ~                             │ Suhu: 348.4 Kelvin       │
│         ~ ~ ~ ~ (Garis Angin Bergerak)      │ Wilayah: Pelalawan, Riau │
│                                             │ Keyakinan: High (92%)    │
│                                             │ Waktu: 13:40 WIB         │
│                                             │ ───────────────────────  │
│                                             │ PM2.5 Sekitar: 142 µg/m³ │
├─────────────────────────────────────────────┴──────────────────────────┤
│ [▶ Play]  ●────────────────────────○───────────────────○  [24 Jam]     │
│           Kemarin (18 Okt)       Tadi Pagi (19 Okt)      Sekarang (WIB)│
└────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Checklist Kualitas Anti-Slop (10 Aturan Emas)

1. ❌ **Tidak ada kartu putih mengambang dengan bayangan berlebihan.** Gunakan kontras border 1px tajam (`border-[#212833]`) dengan latar surface gelap.
2. ❌ **Tidak ada teks hero generik 3 baris rata tengah.** Hero menggunakan tipografi serif besar rata kiri dengan layout berimbang.
3. ❌ **Tidak ada ikon generik di dalam lingkaran gradien.** Ikon murni garis tipis fungsional (Lucide Icons) dengan ukuran tepat (16–18px).
4. ❌ **Tidak ada animasi loading spinner default membosankan.** Gunakan skeleton telemetry gelap dengan pendar bara api halus.
5. ❌ **Tidak ada kedipan peta saat menggeser waktu.** Animasi waktu partikel angin menggunakan GPU dissolve canvas.
6. ❌ **Tidak ada warna gradien ungu-pink klise.** Warna ungu hanya diperuntukkan bagi level polusi udara berbahaya menurut standar WHO.
7. ✅ **Angka data menggunakan font monospaced tabular.** Memastikan angka koordinat dan hitungan titik api stabil tidak bergoyang.
8. ✅ **Label bahasa Indonesia yang lugas dan tepat.** Menggunakan istilah resmi geospasial (misal: *Titik Panas*, *Anomali Termal*, *Kecepatan Angin*, *Indeks Partikulat*).
9. ✅ **Dukungan sentuhan layar mobile yang presisi.** Kontrol peta dan drawer bawah (*bottom sheet*) nyaman dioperasikan satu jempol di smartphone.
10. ✅ **Transparansi batas citra satelit.** Selalu cantumkan timestamp satelit dan sumber instrumen di sudut bawah peta.
