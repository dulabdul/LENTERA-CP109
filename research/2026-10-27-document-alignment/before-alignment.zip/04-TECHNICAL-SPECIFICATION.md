# 04 — Technical Specification & Component Breakdown

## 1. Struktur Direktori Proyek

Proyek ini menggunakan **Next.js 14 (App Router)** mandiri yang sangat ramping:

```
cp-lentera-karthula/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Root layout, Google Fonts (Fraunces & Plus Jakarta Sans)
│   │   ├── globals.css             # Tailwind CSS & custom animations
│   │   ├── page.tsx                # Halaman Utama (Hero Section & Telemetry Ticker)
│   │   ├── peta/
│   │   │   └── page.tsx            # Halaman Dashboard Peta Karhutla & PM2.5
│   │   ├── sumber-data/
│   │   │   └── page.tsx            # Halaman Sumber Data & Transparansi Ilmiah
│   │   └── api/
│   │       ├── fires/
│   │       │   └── route.ts        # Edge Handler: Parse CSV NASA FIRMS -> GeoJSON
│   │       └── air/
│   │           └── route.ts        # Edge Handler: Open-Meteo PM2.5 & Wind Vector
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Navbar.tsx          # Navigasi atas dengan status live indicator
│   │   │   ├── Footer.tsx          # Footer dengan lisensi dan link sumber terbuka
│   │   │   └── TelemetryCard.tsx   # Kartu metrik modular dengan font monospaced
│   │   └── map/
│   │       ├── MapView.tsx         # Container MapLibre GL JS & inisialisasi basemap
│   │       ├── HotspotLayer.tsx    # Layer GeoJSON titik api NASA dengan efek pendar
│   │       ├── WindParticleCanvas.tsx # Canvas 2D partikel arah angin & PM2.5
│   │       ├── TimelineSlider.tsx  # Slider pengendali rentang waktu (24h/48h/7d)
│   │       └── TelemetryHUD.tsx    # Heads-Up Display panel informasi titik aktif
│   ├── lib/
│   │   ├── firms.ts                # Fetcher & parser CSV satelit NASA FIRMS
│   │   ├── air-quality.ts          # Normalisasi data PM2.5 dan perhitungan arah angin
│   │   ├── constants.ts            # Batas koordinat Indonesia (Sabang-Merauke) & BBOX
│   │   └── types.ts                # Definisi antarmuka TypeScript
│   └── hooks/
│       ├── useFiresData.ts         # Hook SWR/React Query untuk polling data titik api
│       └── useWindowSize.ts        # Deteksi resolusi mobile vs desktop
├── public/
│   └── images/                     # Asset grafis dan ilustrasi asli
├── tailwind.config.ts              # Konfigurasi token warna obsidian/ember
├── package.json                    # Dependensi minimal tanpa monorepo overhead
└── tsconfig.json                   # Konfigurasi TypeScript strict mode
```

---

## 2. Definisi Tipe Data (*Data Models*)

File: `src/lib/types.ts`

```typescript
/** Format data satu titik panas karhutla yang dinormalisasi */
export interface HotspotRecord {
  id: string;
  latitude: number;
  longitude: number;
  brightnessKelvin: number;    // Suhu kecerahan inframerah
  acqDate: string;             // Tanggal deteksi (YYYY-MM-DD)
  acqTime: string;             // Waktu deteksi (HHMM UTC)
  confidence: "nominal" | "high" | "low";
  satellite: "VIIRS-SNPP" | "NOAA-20" | "MODIS";
  frp?: number;                // Fire Radiative Power (Megawatt)
}

/** GeoJSON Feature untuk efisiensi MapLibre GL */
export interface HotspotGeoJSON {
  type: "FeatureCollection";
  features: Array<{
    type: "Feature";
    geometry: {
      type: "Point";
      coordinates: [number, number]; // [Lng, Lat]
    };
    properties: Omit<HotspotRecord, "latitude" | "longitude">;
  }>;
}

/** Data pergerakan angin dan kualitas udara */
export interface AirVectorStep {
  timestamp: string;
  pm25Concentration: number;   // µg/m³
  windSpeed: number;           // km/h
  windDirection: number;       // derajat (0 = Utara, 90 = Timur)
  uComponent: number;          // Komponen angin sumbu X
  vComponent: number;          // Komponen angin sumbu Y
}

/** Ringkasan Telemetri Nasional */
export interface TelemetrySummary {
  totalHotspots24h: number;
  highConfidenceCount: number;
  highestRegionName: string;
  peakPm25Value: number;
  lastUpdatedIso: string;
}
```

---

## 3. Spesifikasi Logika Komponen Kunci

### A. Route Handler API Titik Api: `src/app/api/fires/route.ts`
* **Metode:** `GET`
* **Logika Kerja:**
  1. Cek parameter query: `range=24h` (default), `48h`, atau `7d`.
  2. Panggil API NASA FIRMS CSV:
     ```
     https://firms.modaps.eosdis.nasa.gov/api/country/csv/${KEY}/VIIRS_SNPP_NRT/IDN/${days}
     ```
  3. Parse baris CSV tanpa library berat (menggunakan split stream sederhana).
  4. Konversi baris ke format GeoJSON `FeatureCollection`.
  5. Kirim response dengan header caching:
     ```typescript
     return NextResponse.json(geoJsonData, {
       headers: {
         "Cache-Control": "public, s-maxage=1800, stale-while-revalidate=3600",
       },
     });
     ```

---

### B. Inisialisasi Peta: `src/components/map/MapView.tsx`
* Menggunakan library `maplibre-gl`.
* Inisialisasi posisi awal menghadap kepulauan Indonesia:
  ```typescript
  const map = new maplibregl.Map({
    container: mapContainerRef.current,
    style: {
      version: 8,
      sources: {
        "carto-dark": {
          type: "raster",
          tiles: ["https://basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png"],
          tileSize: 256,
          attribution: "© OpenStreetMap contributors, © CARTO",
        },
      },
      layers: [
        {
          id: "carto-dark-layer",
          type: "raster",
          source: "carto-dark",
          minzoom: 0,
          maxzoom: 19,
        },
      ],
    },
    center: [118.0, -2.5], // Pusat kepulauan Indonesia
    zoom: 4.8,
    maxBounds: [85.0, -15.0, 145.0, 10.0], // Mengunci panning di wilayah Asia Tenggara/Indonesia
  });
  ```

---

### C. Layer Titik Api Berpendar: `src/components/map/HotspotLayer.tsx`
* Menambahkan GeoJSON source `"hotspots-data"`.
* Layer lingkaran (*circle*) dengan ekspresi gaya MapLibre:
  ```typescript
  map.addLayer({
    id: "hotspots-glow",
    type: "circle",
    source: "hotspots-data",
    paint: {
      // Ukuran membesar halus seiring zoom
      "circle-radius": [
        "interpolate", ["linear"], ["zoom"],
        4, 3,
        8, 7,
        12, 14
      ],
      // Warna berpendar berdasarkan tingkat keyakinan
      "circle-color": [
        "match",
        ["get", "confidence"],
        "high", "#FF3E24",
        "nominal", "#FF9E1B",
        "#FFC83B"
      ],
      "circle-opacity": 0.85,
      "circle-blur": 0.2,
      "circle-stroke-width": 1.5,
      "circle-stroke-color": "#FFFFFF",
      "circle-stroke-opacity": 0.6
    }
  });
  ```

---

### D. Layer Partikel Angin: `src/components/map/WindParticleCanvas.tsx`
* Elemen `<canvas>` posisi `absolute inset-0 pointer-events-none`.
* Di-update pada setiap pergeseran peta (`map.on("move", updateCanvas)`).
* Menjalankan partikel loop:
  1. Buat array 500–1.000 partikel acak di viewport.
  2. Pada setiap frame `requestAnimationFrame`:
     * Gambar garis pendek (*trace line*) sesuai vektor arah angin $(u, v)$.
     * Jika partikel keluar layar atau usianya habis (*maxAge*), hidupkan kembali di posisi acak baru.
     * Terapkan efek fading tipis: `ctx.fillStyle = "rgba(9, 13, 18, 0.05)"; ctx.fillRect(...)`.
