# Lentera Karhutla — Master Implementation Plan

> **Observatorium Publik Independen Pemantau Kebakaran Hutan & Lahan (Karhutla) dan Kualitas Udara (PM2.5) Indonesia.**

> **Pembaruan analisis — 27 Oktober 2026:** Baca [06-MANDUM-RIMBA-ANALYSIS.md](06-MANDUM-RIMBA-ANALYSIS.md) untuk hasil pemeriksaan situs, kode sumber publik, dan respons API. Fokus produk terbaru adalah **hotspot, PM2.5/kualitas udara, dan rekomendasi tindakan masyarakat**. Dokumen 01–05 merupakan rencana awal dan belum implementasi; koreksi pada bagian 8 dokumen 06 harus dipakai sebelum mengeksekusi rencana tersebut. Bukti ringkas tersedia di [evidence.json](research/2026-10-27-mandum-rimba/evidence.json).

Dokumen ini merupakan panduan arsitektur dan implementasi teknis lengkap untuk membangun **Lentera Karhutla** secara *clean-room* (ditulis ulang dari nol), dengan mengambil referensi teknik terbaik dari rekayasa balik (*reverse engineering*) repositori [ammar-rasyidi/mandum-rimba](file:///Users/naoo/P.A.R.A/PROJECTS/rea-analysis-mamdurimba/mandum-rimba-source) menggunakan **REA skillset**, serta menerapkan standar estetika tinggi bebas slop melalui **Anti-Slop Taste Skill** (`Leonxlnx/taste-skill`).

---

## 📌 Indeks Dokumen Rencana Implementasi

Rencana implementasi ini dibagi ke dalam 5 dokumen modular:

| Dokumen | Topik Pembahasan |
| :--- | :--- |
| **[01-PRODUCT-REQUIREMENTS.md](file:///Users/naoo/P.A.R.A/PROJECTS/cp-lentera-karthula/01-PRODUCT-REQUIREMENTS.md)** | **Product Requirements Document (PRD):** Latar belakang, ruang lingkup (3 fitur inti), user personas, matriks fitur, dan batasan teknis. |
| **[02-ARCHITECTURE-DESIGN.md](file:///Users/naoo/P.A.R.A/PROJECTS/cp-lentera-karthula/02-ARCHITECTURE-DESIGN.md)** | **Desain Arsitektur & Data Pipeline:** Arsitektur *Zero-Database Serverless*, integrasi NASA FIRMS & Open-Meteo, MapLibre GL, dan teknik canvas rendering 60 FPS dari REA. |
| **[03-UI-UX-DESIGN-SYSTEM.md](file:///Users/naoo/P.A.R.A/PROJECTS/cp-lentera-karthula/03-UI-UX-DESIGN-SYSTEM.md)** | **Design System & Anti-Slop Direction:** Art direction editorial observatorium, palet warna *volcanic ember*, tipografi berkarakter, wireframe layout, dan audit no-slop. |
| **[04-TECHNICAL-SPECIFICATION.md](file:///Users/naoo/P.A.R.A/PROJECTS/cp-lentera-karthula/04-TECHNICAL-SPECIFICATION.md)** | **Spesifikasi Teknis & Kode:** Struktur direktori, definisi tipe data TypeScript, spesifikasi komponen React (`MapView`, `AirField`, `TimelineSlider`), dan API routes. |
| **[05-IMPLEMENTATION-ROADMAP.md](file:///Users/naoo/P.A.R.A/PROJECTS/cp-lentera-karthula/05-IMPLEMENTATION-ROADMAP.md)** | **Rencana Eksekusi Bertahap (Roadmap):** Fase 1 s/d Fase 5, checklist verifikasi per milestone, pengujian performa, dan panduan deployment. |

---

## 🎯 Ringkasan Eksekutif & Prinsip Utama

### 1. Filosofi *Clean-Room* (100% Bebas Lisensi Pihak Ketiga)
* **Zero-Copy Policy:** Tidak ada baris kode atau aset grafis (logo, SVG) yang disalin dari repositori Mandum Rimba.
* **Inspirasi Teknik (REA Findings):** Mempelajari pola integrasi MapLibre GL, manipulasi canvas, dan endpoint satelit terbuka dari `mandum-rimba-source`, lalu menulis implementasinya sendiri secara independen.
* **Kepemilikan Penuh:** Proyek ini 100% menjadi hak milik pengembang sendiri, bebas menggunakan lisensi MIT/Apache atau closed-source.

### 2. Tiga Fitur Inti (Fokus & Ringan)
1. **Halaman Utama (Editorial Hero Section):** Menghadirkan konteks urgensi kebakaran hutan dan polusi kabut asap di Indonesia dengan visual berkarakter, metrik telemetry langsung, dan ajakan aksi ke peta.
2. **Dashboard Peta Interaktif (Karhutla & PM2.5):** Menampilkan sebaran titik panas satelit NASA (VIIRS/MODIS) secara real-time dipadukan dengan lapisan simulasi partikel angin dan konsentrasi PM2.5.
3. **Halaman Sumber Data & Transparansi:** Dokumentasi metodologi ilmiah, daftar penyedia data publik, lisensi data terbuka, dan batasan interpretasi citra satelit.

### 3. Standar Estetika *Anti-Slop*
* Menghindari desain template AI yang generik (misal: hero teks rata tengah membosankan, background ungu gradien klise, atau kartu mengambang tanpa guna).
* Membangun identitas visual observatorium yang muram namun fungsional: *Dark-mode first, charcoal ash, ember glowing hotspots, technical telemetry typography*.
