# 02 — Architecture Design & Data Pipeline

## 1. Diagram Arsitektur Sistem (*Zero-Database Serverless*)

Berbeda dari arsitektur monorepo Mandum Rimba yang memiliki database PostgreSQL, NestJS backend, dan serverless Python Modal, **Lentera Karhutla** mengadopsi arsitektur **Stateless Edge Computing**:

```mermaid
graph TD
    User([Pengguna / Browser]) -->|HTTPS / Next.js 14 App| EdgeCDN[Vercel Edge Network / Cloudflare Pages]
    
    subgraph Frontend [Client-Side Browser Runtime]
        UI[Next.js App Router Components]
        MapEngine[MapLibre GL JS v5]
        ParticleCanvas[HTML5 Canvas 2D Particle Loop]
        MapEngine --- ParticleCanvas
    end
    
    subgraph EdgeAPI [Next.js Route Handlers / Edge Cache]
        ProxyFires[/api/fires]
        ProxyAir[/api/air]
    end
    
    subgraph ExternalSources [Penyedia Data Publik Terbuka]
        NASAFIRMS[(NASA FIRMS API - Hotspots)]
        OpenMeteo[(Open-Meteo CAMS - PM2.5 & Wind)]
        CartoCDN[(CARTO Basemap Tiles)]
    end
    
    User --> Frontend
    Frontend --> EdgeAPI
    Frontend -->|Raster Tiles Basemap| CartoCDN
    ProxyFires -->|Sate-cached 30m| NASAFIRMS
    ProxyAir -->|Hourly-cached| OpenMeteo
```

---

## 2. Pelajaran Rekayasa Balik (Pola Teknik REA)

Dari analisis terhadap [`mandum-rimba-source`](file:///Users/naoo/P.A.R.A/PROJECTS/rea-analysis-mamdurimba/mandum-rimba-source), terdapat beberapa **pola rekayasa performa tinggi** yang diadopsi ke dalam Lentera Karhutla:

### A. Animasi Partikel Angin di Luar WebGL (`AirField` Pattern)
* **Masalah pada Mapbox/MapLibre biasa:** Menggambar ribuan partikel vektor di WebGL layer peta sering kali menyebabkan *state thrashing*, memory leak, dan drop FPS saat peta digeser/di-zoom.
* **Solusi Teruji:**
  * Lapisan partikel angin digambar pada elemen **HTML5 Canvas 2D murni** yang ditempatkan secara overlay tepat di atas canvas MapLibre.
  * Canvas partikel bersifat *screen-space* (hanya menggambar apa yang tampak di viewport).
  * Saat peta digeser (*pan/zoom*), canvas partikel di-clear dan disesuaikan koordinat transformasinya, menghasilkan performa stabil 60 FPS bahkan di smartphone.

### B. Meniadakan Kedipan Antar Waktu (*Zero-Flicker Dissolve*)
* **Pola:** Transisi data per jam tidak melakukan hapus-dan-pasang (*removeLayer / addLayer*) pada peta, karena akan menyebabkan layar berkedip hitam (*blink*) saat layer baru di-inisialisasi.
* **Solusi:** Dua frame waktu di-render ke canvas offscreen, lalu digabungkan menggunakan `ctx.globalAlpha` cross-fade. GPU memproses blending opacity ini secara instan tanpa lag.

### C. Bounding Box Optimization (Batas Geografis Indonesia)
* Data satelit global sangat masif (ratusan megabyte per hari).
* Query NASA FIRMS dan partikel dibatasi secara ketat pada koordinat batas maritim Indonesia (*Sabang sampai Merauke*):
  ```typescript
  export const INDONESIA_BBOX: [number, number, number, number] = [
    94.5,  // Longitude Barat (Sabang / Ulee Lheue)
    -11.2, // Latitude Selatan (Pulau Rote)
    141.5, // Longitude Timur (Merauke / Perbatasan PNG)
    6.5    // Latitude Utara (Pulau Miangas)
  ];
  ```
  Ini memangkas ukuran payload data dari puluhan MB menjadi **hanya ~30–80 KB** per request!

---

## 3. Data Pipeline & Integrasi API Publik

### 1. Titik Api NASA FIRMS (Fire Information for Resource Management System)
* **Endpoint Resmi:** `https://firms.modaps.eosdis.nasa.gov/api/country/csv/[MAP_KEY]/VIIRS_SNPP_NRT/IDN/1`
* **Format:** CSV streaming (ringan dan hemat kompresi).
* **Kolom Kunci:** `latitude`, `longitude`, `bright_ti4` (suhu kecerahan Kelvin), `acq_date`, `acq_time`, `confidence`.
* **Caching Edge:**
  * Di-proxy melalui Route Handler `/api/fires`.
  * Response header: `Cache-Control: s-maxage=1800, stale-while-revalidate=3600` (cache 30 menit di CDN Vercel sehingga tidak membebani rate limit akun NASA).

### 2. Kualitas Udara PM2.5 & Vektor Angin (Open-Meteo)
* **Endpoint:** `https://air-quality-api.open-meteo.com/v1/air-quality`
* **Parameter:** `latitude`, `longitude`, `hourly=pm2_5,wind_speed_10m,wind_direction_10m`.
* **Keuntungan:** Bebas biaya, tidak memerlukan kartu kredit, dan menggunakan model atmosfer Copernicus CAMS.

### 3. Peta Dasar Vektor & Raster (CARTO)
* **Dark Mode Basemap:** `https://basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png`
* **Light Mode Basemap:** `https://basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png`
* Menggunakan atribusi resmi: `© OpenStreetMap contributors, © CARTO`.

---

## 4. Keamanan, Stabilitas, & Kepatuhan Hukum

1. **Clean-Room Verification:** Seluruh implementasi ditulis menggunakan komponen React mandiri. Tidak ada dependensi ke `@mandumrimba/shared` atau modul internal repositori asli.
2. **Kerahasiaan API Key:** Kunci NASA FIRMS (`FIRMS_MAP_KEY`) disimpan di sisi server via *Environment Variables* Vercel dan tidak terekspos ke browser pengguna.
3. **Graceful Fallback:** Jika API satelit NASA mengalami *downtime*, sistem secara otomatis menyajikan data snapshot *cached* terakhir tanpa membuat UI mengalami *crash*.
