# 05 — Implementation Roadmap & Execution Checklist

Rencana kerja ini disusun secara bertahap (*phased milestones*) agar pengerjaan terstruktur, teruji di setiap langkah, dan langsung dapat dievaluasi.

---

## 📅 Rencana Tahapan Eksekusi (*Phased Execution Plan*)

```
[ Fase 1: Setup & Design ] ──> [ Fase 2: MapLibre Base ] ──> [ Fase 3: NASA Hotspots ]
                                                                       │
[ Fase 5: Polish & Deploy ] <── [ Fase 4: PM2.5 & Partikel ] <─────────┘
```

---

### 🟢 FASE 1: Inisialisasi Proyek & Sistem Desain (Hari 1)
* **Tujuan:** Membangun fondasi proyek Next.js yang bersih, terbebas dari monorepo overhead, dan siap dengan token warna anti-slop.
* **Tugas Spesifik:**
  1. Inisialisasi Next.js 14 dengan TypeScript dan Tailwind CSS:
     ```bash
     npx create-next-app@latest ./ --typescript --tailwind --eslint --app --src-dir --no-import-alias
     ```
  2. Pasang library esensial:
     ```bash
     npm install maplibre-gl lucide-react swr
     npm install -D @types/maplibre-gl
     ```
  3. Konfigurasi font Google di `src/app/layout.tsx`: `Fraunces` (Headline) dan `Plus Jakarta Sans` (Body).
  4. Daftarkan token warna khusus (`bg-obsidian`, `fire-high`, `border-subtle`) di `tailwind.config.ts`.
* **Kriteria Keberhasilan (Milestone 1):** Halaman awal berjalan di `http://localhost:3000` dengan palet warna obsidian gelap dan tipografi berwibawa.

---

### 🟢 FASE 2: Peta Dasar & Navigasi Geografis Indonesia (Hari 2)
* **Tujuan:** Menampilkan peta MapLibre GL dengan basemap gelap yang halus dan terkunci pada kepulauan Indonesia.
* **Tugas Spesifik:**
  1. Buat komponen `MapView.tsx` yang menangani inisialisasi MapLibre GL.
  2. Integrasikan basemap CARTO Dark Matter (`rastertiles/dark_all`).
  3. Kunci koordinat pandangan (*fitBounds*) pada wilayah Indonesia: `[94.5, -11.2, 141.5, 6.5]`.
  4. Tambahkan tombol kontrol navigasi (Zoom In/Out, Reset View Sabang–Merauke).
  5. Pastikan canvas peta resize secara otomatis saat jendela browser berubah ukuran atau orientasi mobile diputar.
* **Kriteria Keberhasilan (Milestone 2):** Peta hitam-arang Indonesia muncul dengan mulus pada 60 FPS tanpa lag saat di-pan/zoom.

---

### 🟢 FASE 3: Pipeline Titik Api Karhutla NASA FIRMS (Hari 3)
* **Tujuan:** Menghubungkan data live satelit NASA dan menampilkannya sebagai titik api berpendar di atas peta.
* **Tugas Spesifik:**
  1. Daftar gratis akun di [NASA FIRMS API](https://firms.modaps.eosdis.nasa.gov/api/map_key) untuk mendapatkan `FIRMS_MAP_KEY`.
  2. Buat Route Handler `/api/fires/route.ts` yang men-download CSV streaming dan mengonversinya menjadi GeoJSON.
  3. Terapkan header caching edge (`s-maxage=1800`) agar aman dari batas kuota API.
  4. Buat komponen `HotspotLayer.tsx` untuk menampilkan titik lingkaran pendar (*glowing circle*).
  5. Tambahkan interaksi klik: Saat titik api diklik, tampilkan popup koordinat, suhu Kelvin, dan tingkat keyakinan (*confidence*).
* **Kriteria Keberhasilan (Milestone 3):** Ratusan titik api aktif di Sumatera dan Kalimantan muncul di peta secara akurat dan interaktif.

---

### 🟢 FASE 4: Lapisan PM2.5, Vektor Angin, & Timeline Waktu (Hari 4)
* **Tujuan:** Memvisualisasikan ke arah mana asap tertiup dan mengontrol rentang waktu pemantauan.
* **Tugas Spesifik:**
  1. Buat komponen `WindParticleCanvas.tsx` yang menggambar partikel angin pada canvas 2D overlay di atas MapLibre.
  2. Sambungkan Route Handler `/api/air/route.ts` ke Open-Meteo Air Quality API untuk mengambil vektor angin $(u, v)$ dan konsentrasi PM2.5.
  3. Buat komponen `TimelineSlider.tsx` yang memungkinkan pengguna memilih rentang: **24 Jam**, **48 Jam**, dan **7 Hari**.
  4. Buat panel `TelemetryHUD.tsx` yang menampilkan jumlah total titik api yang sedang aktif saat rentang waktu diubah.
* **Kriteria Keberhasilan (Milestone 4):** Garis-garis angin bergerak halus di atas peta menunjukkan dinamika aliran kabut asap tanpa memperlambat FPS peta.

---

### 🟢 FASE 5: Halaman Hero, Sumber Data, Audit Anti-Slop, & Deploy (Hari 5)
* **Tujuan:** Menyelesaikan UI halaman beranda, dokumentasi transparansi ilmiah, evaluasi estetika, dan publikasi online.
* **Tugas Spesifik:**
  1. Bangun `src/app/page.tsx` (Hero Section berkarakter editorial + Live Telemetry Ticker).
  2. Bangun `src/app/sumber-data/page.tsx` (Daftar sumber data NASA, CAMS, metodologi, dan lisensi MIT).
  3. Lakukan **Anti-Slop Audit** sesuai pedoman `taste-skill`:
     * Pastikan tidak ada kartu melayang dengan bayangan murahan.
     * Pastikan angka telemetri menggunakan font monospaced tabular.
     * Pastikan teks editorial tajam dan tidak generik.
  4. Deployment ke **Vercel**:
     * Masukkan Environment Variable `FIRMS_MAP_KEY`.
     * Uji performa di Google Lighthouse (Target skor: >90 di Performance & Accessibility).
* **Kriteria Keberhasilan (Milestone 5):** Website tayang langsung di domain publik Vercel dan siap dibagikan.

---

## 🧪 Panduan Pengujian & Checklist Verifikasi

| Item Pengujian | Metode Verifikasi | Standar Kelulusan |
| :--- | :--- | :--- |
| **Peta FPS Test** | DevTools Performance tab saat menggeser peta dengan 1.000 partikel angin aktif | $\ge 50$ FPS (Desktop), $\ge 40$ FPS (Mobile) |
| **Edge Cache Test** | Request ulang ke `/api/fires` | Status `HIT` atau latensi response $< 100$ ms |
| **API Fallback Test** | Matikan koneksi internet saat peta dibuka | Peta menampilkan data offline *fallback snapshot* tanpa error layar putih |
| **Mobile UX Test** | Buka di Chrome DevTools pada viewport iPhone SE & Galaxy S20 | Seluruh kontrol peta dan ticker terbaca tanpa horizontal overflow |
| **Anti-Slop Audit** | Periksa kontras warna, hierarki teks, dan kebersihan layout | Lulus 10 aturan emas desain tanpa template generik |
