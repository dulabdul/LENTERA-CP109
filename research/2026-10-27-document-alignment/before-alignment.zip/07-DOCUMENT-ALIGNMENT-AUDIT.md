# Audit kesesuaian dokumen 01–05 terhadap analisis 06

Tanggal: **27 Oktober 2026**.

## 1. Hasil audit

**Belum sesuai. Kelima dokumen memerlukan revisi substantif sebelum dipakai bersama sebagai spesifikasi implementasi.** Dasar stack dan beberapa batas scope sudah cocok, tetapi fitur rekomendasi masyarakat belum diturunkan ke PRD, arsitektur, UX, kontrak teknis, ataupun roadmap. Ada pula pertentangan integrasi provider, pengelolaan umur data, definisi indeks, dan prioritas MVP.

Audit ini membandingkan isi dokumen lokal dengan [06-MANDUM-RIMBA-ANALYSIS.md](06-MANDUM-RIMBA-ANALYSIS.md). Audit tidak mengulang pemeriksaan layanan eksternal dan tidak menyatakan kondisi API saat ini di luar pengamatan yang tercatat dalam dokumen 06. Tidak ada aplikasi yang diuji karena workspace masih berisi dokumen rencana.

Dokumen 01–06 dan README **tidak diubah** dalam audit ini. Nomor baris yang dicantumkan merujuk versi pada saat pemeriksaan.

Dua jenis acuan pada 06 perlu dibedakan:

- **Temuan berbukti:** misalnya database pada sumber Mandum adalah MongoDB, dan percobaan endpoint air-quality tidak menghasilkan data angin. Ini mengoreksi asumsi lama.
- **Usulan desain Lentera:** misalnya PM2.5 per lokasi untuk MVP, grid/partikel pada fase berikutnya, dan usulan estimasi US AQI PM2.5. Usulan ini perlu menjadi keputusan konsisten pada PRD dan spesifikasi; bukan berarti semua teknologi Mandum harus digunakan.

## 2. Status setiap dokumen

| Dokumen | Sudah sesuai | Belum sesuai / belum lengkap | Penilaian |
| --- | --- | --- | --- |
| [01 — PRD](01-PRODUCT-REQUIREMENTS.md) | Fokus karhutla/udara, hotspot interaktif, sumber data, pembatasan fitur satwa/konsesi, privasi | Tiga pilar masih hero/peta/sumber; rekomendasi tidak ada; partikel/grid menjadi kebutuhan inti; belum ada metode indeks dan persyaratan kesegaran; biaya nol dinyatakan pasti | Perlu revisi besar pada scope dan kriteria keberhasilan |
| [02 — Arsitektur](02-ARCHITECTURE-DESIGN.md) | Satu aplikasi, MapLibre, proxy server, API key server-side, cache dan niat fallback | Referensi PostgreSQL salah; FIRMS country; endpoint udara/angin digabung; scheduler dan snapshot persisten belum dirancang; jalur rekomendasi tidak ada | Perlu revisi besar pada aliran data |
| [03 — UI/UX](03-UI-UX-DESIGN-SYSTEM.md) | Identitas visual mandiri, angka tabular, rancangan mobile, timestamp dan sumber | Panel tindakan/lokasi/indeks tidak lengkap; tidak ada tampilan stale/missing/partial; “Live Sensor Stream”, “High (92%)”, dan warna kategori tidak sejalan dengan 06 | Arah visual dapat dipertahankan; alur dan semantik data perlu revisi besar |
| [04 — Spesifikasi teknis](04-TECHNICAL-SPECIFICATION.md) | GeoJSON, koordinat [lng, lat], kategori confidence, tipe dasar hotspot, MapLibre | Belum ada tipe snapshot, status kesegaran, indeks, dan aturan rekomendasi; country API masih dipakai; logika waktu/7d tidak cukup; tipe udara tidak menyatakan lokasi/grid; belum ada kontrak panel udara | Perlu revisi besar pada kontrak data dan API |
| [05 — Roadmap](05-IMPLEMENTATION-ROADMAP.md) | Tahapan bertahap, interaksi peta, penyimpanan key server, perhatian mobile/performa | Tidak ada milestone rekomendasi, indeks, scheduler, snapshot, atau kesegaran; integrasi angin salah; partikel mendahului fitur inti; kelulusan bergantung jumlah titik; pengujian fallback/offline tercampur | Perlu revisi besar pada urutan kerja dan acceptance criteria |

Tidak digunakan persentase kesesuaian karena belum ada bobot dan daftar acceptance criteria yang disepakati; persentase akan memberi ketelitian semu.

## 3. Temuan yang harus diselesaikan lebih dahulu

Prioritas **P0** berarti harus dituntaskan dalam spesifikasi sebelum implementasi bagian tersebut dimulai. **P1** berarti perlu dilengkapi agar rancangan dan rencana rilis dapat diverifikasi. **P2** berarti perapian klaim dan konsistensi dokumentasi.

### F01 — P0: satu fitur utama pengguna belum tercakup di seluruh rantai dokumen

**Lokasi:** PRD baris 16–27 dan 63–72; struktur komponen pada 04 baris 9–41; semua fase pada 05. **Acuan:** 06 baris 5–11, 139, dan 186–203.

PRD mendefinisikan hero, peta, dan sumber data sebagai tiga pilar. Kelima dokumen belum mendefinisikan rekomendasi tindakan masyarakat. Akibatnya, pengembang dapat menyelesaikan seluruh fase roadmap lama tanpa memenuhi salah satu dari tiga kebutuhan pengguna.

Revisi yang diperlukan:

- PRD: definisikan hotspot, kualitas udara, dan tindakan masyarakat sebagai tiga kemampuan inti; hero/sumber data menjadi pendukung.
- Arsitektur: tambahkan modul aturan yang memakai data tervalidasi, kategori indeks, dan status kesegaran.
- UX: panel “Tindakan untuk lokasi ini”, alasan rekomendasi, waktu berlaku, kelompok sasaran dan rujukan sumber.
- Spesifikasi: `ruleId`, `ruleVersion`, alasan/input, kategori pengguna, `createdAt`, `validUntil`, dan perilaku bila data tidak cukup.
- Roadmap: milestone implementasi serta verifikasi semua batas kategori, data hilang, dan data kedaluwarsa.

### F02 — P0: kesegaran dan kegagalan data belum menjadi kontrak produk

**Lokasi:** PRD baris 32–35 dan 81; 03 baris 58–68 dan 77; 04 baris 93–98; 05 baris 91. **Acuan:** 06 baris 93–95, 169–175, dan 230.

Dokumen lama masih menekankan live, waktu terakhir diperbarui, cache HIT, dan latensi. Tidak ada kontrak terpisah untuk `ok`, `stale`, `unavailable`, dan `partial`, padahal 06 memperlihatkan respons HTTP sukses yang berisi rekaman akuisisi jauh lebih lama.

Tambahkan waktu pengambilan, rentang cakupan, waktu deteksi, waktu berlaku sampel, dan run model bila tersedia. Tentukan kebijakan kesegaran per sumber, termasuk batas stale dan perilaku saat gagal. Tampilkan perbedaannya pada UI dan uji. `stale-while-revalidate` pada header bukan status kualitas data di dalam payload.

Keberadaan nol rekaman, kegagalan mengambil data, dan rekaman lama harus dapat dibedakan. Jangan memakai waktu deteksi terbaru sebagai satu-satunya bukti kesehatan pengambilan: area dengan nihil deteksi yang sah tetap membutuhkan metadata keberhasilan dan cakupan query.

### F03 — P0: integrasi angin masih memakai endpoint kualitas udara

**Lokasi:** 02 baris 25 dan 78–81; 04 baris 22 dan 36; 05 baris 63. **Acuan:** 06 baris 101–105, 180–181, dan 211.

Rancangan lama meminta `pm2_5`, `wind_speed_10m`, dan `wind_direction_10m` pada endpoint air-quality yang sama. Dalam pemeriksaan yang dicatat 06, PM2.5 terisi sedangkan angin null; endpoint cuaca terpisah menghasilkan angin.

Pisahkan adapter PM2.5 dari adapter cuaca. Jika angin termasuk fase yang dikerjakan, selaraskan lokasi, waktu berlaku, satuan, sumber model, dan konvensi arah angin sebelum dipakai bersama. Nama route publik boleh dipilih, tetapi tanggung jawab dan bentuk respons harus jelas. Jika MVP mengikuti usulan 06 tanpa partikel, integrasi angin dapat dijadwalkan sesudah panel udara/tindakan.

### F04 — P0: sumber hotspot dan filter rentang belum mengikuti temuan 06

**Lokasi:** 02 baris 71; 04 baris 109–115; PRD baris 46; 05 baris 64. **Acuan:** 06 baris 179, 184, 212–213, dan 231.

Spesifikasi masih bertumpu pada FIRMS country API dan variabel `${days}`. Acuan 06 mencatat country/countries tidak tersedia ketika diperiksa dan merekomendasikan Area API. Acuan itu juga mencatat batas 1–5 hari per query, sedangkan UI menjanjikan 7 hari.

Kontrak harus menyatakan query Area API, pemecahan rentang sesuai batas provider, validasi CSV/error upstream, penggabungan dan deduplikasi teknis, serta penyaringan berdasarkan timestamp UTC. Jangan menganggap jumlah hari kalender dari provider sama dengan jendela bergerak 24/48 jam. Jumlah tanggal kalender yang perlu diambil harus diturunkan dari batas awal/akhir UTC agar tidak kehilangan rekaman di tepi rentang.

Apabila jumlah diberi label “Indonesia”, bbox saja belum cukup; perlu pembatasan dengan geometri wilayah yang dipilih dan sumber batas yang terdokumentasi. Endpoint produksi Mandum bukan upstream aplikasi kita.

### F05 — P0: indeks kualitas udara belum mempunyai definisi yang dapat diimplementasikan

**Lokasi:** PRD baris 35 dan 43; 03 baris 32–34, 68, dan 104; 04 baris 83–98. **Acuan:** 06 baris 123–129, 172, dan 217.

Dokumen lama menyebut indeks/kategori namun tidak memilih US AQI, ISPU, atau metodologi lain. Belum ada rumus, versi breakpoint, periode agregasi, aturan input hilang, maupun hubungan kategori dengan rekomendasi. Palet warna juga diperlakukan sebagai token merek tanpa kontrak enam kategori jika memakai usulan US AQI pada 06.

Pilihan perlu dikunci di PRD dan diturunkan ke semua dokumen. Jika mengikuti usulan 06, PM2.5 µg/m³ menjadi angka utama dan indeks diberi label estimasi US AQI PM2.5 dari rerata bergerak 24 jam model. Tetapkan kelengkapan jam input dan kondisi tidak tersedia. Data model, data sensor, indeks satu polutan, dan indeks gabungan perlu dibedakan. Jika memilih ISPU, seluruh tabel kategori, perhitungan, warna, dan pesan harus mengikuti pilihan tersebut.

## 4. Temuan rancangan dan pengujian

### F06 — P1: fallback dijanjikan tanpa rancangan snapshot persisten

**Lokasi:** PRD baris 72 dan 81; 02 diagram baris 7–34 dan fallback baris 94; 04 struktur direktori; 05 baris 92. **Acuan:** 06 baris 148–150 dan 163–175.

Tidak memakai database relasional masih sejalan dengan 06. Namun arsitektur hanya menunjukkan proxy on-demand dan cache; belum ada object storage, job pengambilan, format snapshot, dan urutan publikasi. Janji last-good snapshot belum mempunyai pemilik penyimpanan dan alur pemulihan.

Tambahkan writer terjadwal, snapshot berstempel waktu, penyimpanan last-good, manifest/penunjuk versi, retry/failure policy, serta status stale saat menyajikan snapshot lama. Publikasikan penunjuk terbaru setelah payload valid selesai disimpan. Cache merupakan lapisan percepatan yang berbeda dari penyimpanan histori/fallback.

Selain itu, pengujian 05 baris 92 mencampur dua kondisi: **upstream gagal ketika pengguna masih online** dan **perangkat pengguna tidak punya internet**. Snapshot server tidak otomatis memberikan dukungan offline pada perangkat. Pisahkan kedua skenario. Nyatakan offline sebagai scope tersendiri bila memang dibutuhkan; jangan menambahnya sebagai syarat implisit MVP.

### F07 — P1: grid dan partikel mendominasi MVP, tetapi kontrak spasialnya belum ada

**Lokasi:** PRD baris 42–44 dan 66; 02 baris 42–51; 04 baris 83–90 dan 196–204; 05 fase 4. **Acuan:** 06 baris 138 dan 159–163.

06 menyarankan panel udara per lokasi untuk MVP serta grid/partikel pada fase lanjutan. Dokumen lama menjadikan keduanya wajib, sementara tipe `AirVectorStep` hanya berisi skalar per timestamp, tanpa lokasi sampel, grid, dimensi, bbox, atau sumber. Data per lokasi tidak cukup untuk menggambarkan medan angin nasional.

Tentukan tahapnya. Jika mengikuti MVP pada 06, spesifikasikan panel lokasi dan seri waktu terlebih dahulu. Jika grid penuh dipilih untuk tahap lain, tambahkan kontrak medan spasial serta pipeline terjadwal/CDN yang sesuai. Partikel perlu dijelaskan sebagai visualisasi angin; kalimat “ke mana asap tertiup” dan “dinamika kabut asap” belum didukung model transport yang dinyatakan di dokumen.

### F08 — P1: angka dan label UI melebihi bukti data

**Lokasi:** PRD baris 33–35; 03 baris 58–68 dan 81–88; 04 baris 61–65 dan 93–98. **Acuan:** 06 baris 169–175 dan 214–218.

- Mockup `High (92%)` menambahkan persentase yang tidak diturunkan dari kategori confidence VIIRS. Tampilkan kategori asli/normalisasi sesuai instrumen; jangan menyamakan normalisasi VIIRS dan MODIS tanpa aturan.
- Istilah “Live Sensor Stream” mencampur deteksi satelit berkala dengan model atmosfer. Gunakan label model dan waktu berlaku pada panel udara.
- “Wilayah terburuk” atau “PM2.5 tertinggi” tingkat nasional memerlukan cakupan dan metode agregasi nasional. Beberapa lokasi sampel hanya boleh menghasilkan ringkasan sesuai cakupan sampelnya.
- `lastUpdatedIso` tunggal tidak cukup untuk membedakan umur hotspot dari jam berlaku kualitas udara. Makna setiap waktu perlu ditetapkan.
- Label “Suhu” perlu mengikuti makna `brightnessKelvin` yang sudah ditulis pada tipe, bukan memberi kesan pengukuran suhu api di permukaan. Ini perapian semantik internal dokumen, bukan temuan pengukuran baru.

Angka contoh pada wireframe boleh tetap dipakai sebagai ilustrasi bila ditandai. Yang harus diperbaiki adalah makna, unit, kategori, dan klaim sumbernya.

### F09 — P1: roadmap dapat dinyatakan selesai tanpa memenuhi kebutuhan inti

**Lokasi:** 05 baris 17–82 dan 88–94. **Acuan:** 06 baris 228–235.

Roadmap tidak mengalokasikan tugas atau verifikasi untuk F01–F06. Milestone “ratusan titik api aktif” pada baris 55 bergantung pada kondisi alam dan data hari itu; jumlah sedikit/nol yang sah tidak berarti aplikasi gagal. Milestone animasi pada baris 66 tidak memverifikasi panel PM2.5 atau indeks. Cache HIT/latensi tidak memverifikasi kesegaran dan akurasi cakupan.

Urutan yang lebih sesuai dengan 06:

1. Keputusan scope, sumber data, metode indeks, kontrak status dan waktu.
2. Pengambilan data, scheduler, snapshot persisten, dan error/fallback states.
3. Peta hotspot, pencarian lokasi, filter waktu, dan detail sumber.
4. Panel udara beserta metode indeks yang dipilih.
5. Rekomendasi tindakan dan alasan yang dapat ditelusuri.
6. Validasi mobile, aksesibilitas, kualitas data, dan performa sebelum rilis.
7. Grid/partikel dan notifikasi jika masuk tahap lanjutan.

Contoh acceptance criteria yang perlu ditambahkan:

| Skenario | Hasil yang harus diverifikasi |
| --- | --- |
| Respons 200 tetapi isi berumur lama | Status sesuai kebijakan kesegaran, waktu sumber terlihat, tidak mengklaim kondisi terkini |
| Pengambilan berhasil tetapi area nihil deteksi | Nol deteksi pada cakupan yang jelas, terpisah dari kegagalan sumber |
| Upstream gagal | Last-good bila ada dengan status stale; unavailable bila tidak ada |
| Input sebagian atau jam indeks kurang | Status partial/tidak tersedia; tidak mengisi data hilang dengan nol |
| Rentang 7d dan batas 24h/48h | Query dipecah sesuai provider; filter timestamp dan deduplikasi sesuai kontrak |
| Lokasi di luar bbox/cakupan atau hasil bbox lintas negara | Validasi request dan ringkasan sesuai cakupan yang dilabelkan |
| Batas kategori indeks berubah | Perhitungan, warna, label, dan rule rekomendasi tetap konsisten |
| Kelompok pengguna berbeda | Pemilihan pesan sesuai aturan dan sumber pedoman yang dipakai |
| Rekomendasi berdasarkan data stale/missing | Keterbatasan dijelaskan; tidak menghasilkan status “aman” otomatis |

Kriteria FPS juga belum konsisten: PRD baris 79 meminta 60/45 FPS; milestone peta 05 baris 43 meminta 60 FPS; tabel uji 05 baris 90 menerima 50/40 FPS. Gunakan satu target yang menyebut perangkat, skenario, ukuran data, dan metode ukur. Ini bukan hasil benchmark aplikasi yang sudah tersedia.

### F10 — P2: klaim kepastian dan instruksi setup perlu dirapikan

**Lokasi:** PRD baris 16 dan 83; 02 baris 5, 43–51, dan 64; 05 baris 20–30; README baris 7, 18, dan 27–35. **Acuan:** 06 baris 15–32, 159, dan 209–222.

- Ubah penyebutan database Mandum dari PostgreSQL menjadi MongoDB; ini tidak mengharuskan Lentera menambahkan MongoDB.
- Klaim Canvas “solusi teruji”, 60 FPS pada smartphone, GPU instan tanpa lag, dan payload 30–80 KB tidak didukung benchmark CP pada 06. Pisahkan pola implementasi yang terlihat dari target performa yang akan diukur.
- Rp0 per bulan merupakan target bersyarat, bukan jaminan. Dokumen perlu menyebut asumsi trafik, storage, scheduler, dan kuota/jenis penggunaan API.
- 05 menyebut Next.js 14 tetapi memerintahkan `create-next-app@latest`; perintah itu bukan penguncian versi 14. Selaraskan versi framework, dependensi, dan bentuk konfigurasi yang benar-benar dipilih saat implementasi. Tidak ada pemilihan versi baru dalam audit ini.
- Lisensi kode aplikasi sendiri tidak menggantikan atribusi atau ketentuan library/dataset/basemap. Pernyataan README “100% Bebas Lisensi Pihak Ketiga” bertentangan dengan pembatasan klaim pada 06.
- Catatan di awal README sudah menunjuk 06, tetapi ringkasan tiga fitur dan klaim REA/performa di bawahnya masih mengikuti rencana lama. Catatan pembaruan belum berarti isi 01–05 sudah sinkron.

## 5. Bagian yang dapat dipertahankan

| Bagian | Alasan |
| --- | --- |
| Next.js/React/TypeScript satu aplikasi | Sejalan dengan usulan stack ringan pada 06; pilih versi implementasinya secara konsisten |
| MapLibre + GeoJSON + interaksi titik | Cocok untuk pemantauan hotspot yang dapat diperiksa |
| `[longitude, latitude]` pada geometri | Sudah konsisten pada model GeoJSON dan peta |
| API key FIRMS hanya di server | Sejalan dengan 06; lanjutkan tanpa prefix publik |
| Atribusi, sumber dan penjelasan anomali termal | Dasar transparansi sudah ada; tambahkan status/model/metode indeks |
| Fokus di luar fitur satwa, konsesi dan kampanye | Sejalan dengan fokus tiga kemampuan pengguna |
| Tipografi tabular, identitas visual sendiri dan mobile bottom sheet | Dapat dipertahankan sambil memperbaiki keterbacaan, state data dan kategori indeks |
| Niat fallback dan evaluasi performa | Tepat sebagai kebutuhan; perlu desain dan pengujian yang benar-benar mendukungnya |

## 6. Keputusan yang masih perlu ditetapkan saat menyelaraskan dokumen

Ini **detail yang belum diputuskan**, bukan semuanya kesalahan faktual dokumen lama atau keputusan final pada 06:

| Keputusan | Pemilik dokumentasi | Dampak ke dokumen lain |
| --- | --- | --- |
| Standar indeks: usulan US AQI PM2.5 atau ISPU | PRD + metodologi | Tipe data, algoritma, warna, teks rekomendasi, kasus uji |
| Panel udara lokal untuk MVP atau grid lebih awal | PRD | Pipeline, object storage, kontrak spasial, biaya dan roadmap |
| Wilayah, sensor, basemap dan sumber batas awal | PRD + arsitektur | Normalisasi confidence, cakupan hitungan, pencarian dan provider |
| Ambang kesegaran, jadwal pengambilan dan retensi snapshot | Arsitektur + spesifikasi | Label UI, fallback, histori 7d dan verifikasi operasi |
| Nama endpoint kanonis `/api/fires` atau `/api/hotspots` | Spesifikasi | Hooks frontend, diagram dan langkah roadmap; perbedaan nama saja bukan cacat perilaku |
| Satu target performa yang realistis dan terukur | PRD | Skenario benchmark dan kelulusan pada roadmap |

Angka batas stale, pilihan cloud tertentu, dan biaya pasti tidak ditetapkan secara sepihak dalam audit ini.

## 7. Urutan revisi dokumen yang disarankan

1. **01 PRD:** tetapkan tiga kemampuan inti, scope tahap awal, standar indeks dan persyaratan kualitas data.
2. **02 Arsitektur:** turunkan ke alur provider terpisah, scheduler, snapshot, cache, dan modul rekomendasi.
3. **04 Spesifikasi teknis:** tulis kontrak tipe/API, status, perhitungan waktu/indeks, normalisasi sensor dan aturan rekomendasi.
4. **03 UI/UX:** cocokkan panel, label, warna kategori, tindakan pengguna dan seluruh state data dengan kontrak tersebut.
5. **05 Roadmap:** pastikan setiap requirement mempunyai tugas dan kriteria verifikasi, kemudian tempatkan fitur lanjutan sesudah kebutuhan inti.
6. **README:** samakan ringkasan fitur, indeks dokumen dan bahasa klaim dengan keputusan akhir.

Dokumen 06 tetap menjadi catatan analisis/bukti dan usulan. Dokumen 01–05 yang sudah direvisi harus menjadi spesifikasi pelaksanaan yang konsisten, tanpa memerlukan pembaca menyelesaikan konflik antarfile sendiri.
